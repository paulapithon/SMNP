package br.com.poli.redes;

import java.net.URL;
import java.util.ResourceBundle;

import br.com.poli.redes.jni.SNMPMessager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ControllerSNMP implements Initializable {

	@FXML
	private TextField IP_FIELD;
	@FXML
	private TextField Port_FIELD;
	@FXML
	private TextField OID_FIELD;
	private SNMPMessager snmp;

	@FXML
	private TextArea respose;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		snmp = SNMPMessager.getInstance();
		
	}
	@FXML
	public void sendMessage(ActionEvent event)
	{
		String ip = (IP_FIELD.getText());
		String port = (Port_FIELD.getText());
		String oid = (OID_FIELD.getText());
		String oldText = respose.getText();
		String newText = snmp.SendMenssage(ip, port, oid);
		boolean oneIsEmpty = oldText.equals("") ||newText.equals("");
		respose.setText(oldText + (oneIsEmpty?"":"\n") +newText);
		IP_FIELD.setText("");
		Port_FIELD.setText("");
		OID_FIELD.setText("");
	}
	@FXML
	public void clearChace(ActionEvent event)
	{
		respose.setText("");
		IP_FIELD.setText("");
		Port_FIELD.setText("");
		OID_FIELD.setText("");
	}
}
