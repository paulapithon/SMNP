package br.com.poli.redes.jni;

public class SNMPMessager {
	static {
	      System.loadLibrary("SNMPClient"); 
	   }
	private static SNMPMessager instance = null;
	private SNMPMessager() {}
	public static SNMPMessager getInstance(){
		if(instance == null) {
			instance = new SNMPMessager();
		}
		return instance;
	}
	public native String SendMenssage(String ip, String port,String oid);
	 
}
